import React from "react";
import Header from "../parts/Header";
import FreshStories from "../parts/FreshStories";
import Slider from "../parts/Slider";
import TrendingPosts from "../parts/TrendingPosts";
import Footer from "../parts/Footer";

const Home = () => {
  return (
    <>
      <Header />
      <Slider />
      <TrendingPosts />
      <FreshStories />
      <Footer />
    </>
  );
};

export default Home;
