module.exports = {
  MONGOURI:
    "mongodb+srv://abdallahy271:ummulqura271@cluster0.iytbm.mongodb.net/Cluster0?retryWrites=true&w=majority",
};
